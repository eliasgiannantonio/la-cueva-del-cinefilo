package com.example.la_cueva_del_cinefilo_app;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.database.Cursor;

import com.example.la_cueva_del_cinefilo_app.models.DirectorClass;
import com.example.la_cueva_del_cinefilo_app.models.MovieClass;

import com.example.la_cueva_del_cinefilo_app.models.UserClass;

import com.example.la_cueva_del_cinefilo_app.models.CategoryClass;
import com.example.la_cueva_del_cinefilo_app.models.ProductoraClass;
import com.example.la_cueva_del_cinefilo_app.models.FormatClass;
import com.example.la_cueva_del_cinefilo_app.models.LanguageClass;



public class DataBaseSQLiteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "proyecto_db";
    private static final int DATABASE_VERSION = 1;

    public DataBaseSQLiteHelper(Context contexto) {
        super(contexto, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crea la tabla "cliente"
        String createTableCliente = "CREATE TABLE IF NOT EXISTS `cliente` ("
                + "`id_usuario` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`nombre` TEXT NOT NULL, "
                + "`apellido` TEXT NOT NULL, "
                + "`password` TEXT NOT NULL, "
                + "`tipo_usuario` INTEGER NOT NULL, "
                + "`email` TEXT NOT NULL, "
                + "`dni` TEXT, "
                + "`fecha_nac` DATE, "
                + "`telefono` TEXT, "
                + "`fecha_creacion` DATE NOT NULL, "
                + "`fecha_modificacion` DATE);";
        db.execSQL(createTableCliente);

        // Crea la tabla "director"
        String createTableDirector = "CREATE TABLE IF NOT EXISTS `director` ("
                + "`id_director` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`nombre` TEXT NOT NULL, "
                + "`apellido` TEXT NOT NULL);";
        db.execSQL(createTableDirector);

        // Crea la tabla "idioma"
        String createTableIdioma = "CREATE TABLE IF NOT EXISTS `idioma` ("
                + "`id_idioma` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`nombre` TEXT);";
        db.execSQL(createTableIdioma);

        // Crea la tabla "formato"
        String createTableFormato = "CREATE TABLE IF NOT EXISTS `formato` ("
                + "`id_formato` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`tipo` TEXT NOT NULL);";
        db.execSQL(createTableFormato);

        // Crea la tabla "productora"
        String createTableProductora = "CREATE TABLE IF NOT EXISTS `productora` ("
                + "`id_productora` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`nombre` TEXT NOT NULL);";
        db.execSQL(createTableProductora);

        // Crea la tabla "categoria"
        String createTableCategoria = "CREATE TABLE IF NOT EXISTS `categoria` ("
                + "`id_categoria` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`tipo` TEXT NOT NULL);";
        db.execSQL(createTableCategoria);

        // Crea la tabla "movie"
        String createTableMovie = "CREATE TABLE IF NOT EXISTS `movie` ("
                + "`id_movie` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`titulo` TEXT NOT NULL, "
                + "`subtitulo` TEXT, "
                + "`descripcion` TEXT, "
                + "`comentarios` TEXT, "
                + "`director_id_director` INTEGER NOT NULL, "
                + "`idioma_id_idioma` INTEGER NOT NULL, "
                + "`formato_id_formato` INTEGER NOT NULL, "
                + "`productora_id_productora` INTEGER NOT NULL, "
                + "`categoria_id_categoria` INTEGER NOT NULL, "
                + "`calificacion_promedio` REAL DEFAULT 0, "
                + "`numero_calificaciones` INTEGER DEFAULT 0, "
                + "FOREIGN KEY (`director_id_director`) REFERENCES `director` (`id_director`), "
                + "FOREIGN KEY (`idioma_id_idioma`) REFERENCES `idioma` (`id_idioma`), "
                + "FOREIGN KEY (`formato_id_formato`) REFERENCES `formato` (`id_formato`), "
                + "FOREIGN KEY (`productora_id_productora`) REFERENCES `productora` (`id_productora`), "
                + "FOREIGN KEY (`categoria_id_categoria`) REFERENCES `categoria` (`id_categoria`)"
                + ");";
        db.execSQL(createTableMovie);

        // Crea la tabla "wishlist"
        String createTableWishlist = "CREATE TABLE IF NOT EXISTS `wishlist` ("
                + "`id_wishlist` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`fecha_creacion` TEXT, "
                + "`cliente_id_usuario` INTEGER NOT NULL, "
                + "`fecha_modificacion` DATE, "
                + "FOREIGN KEY (`cliente_id_usuario`) REFERENCES `cliente` (`id_usuario`));";
        db.execSQL(createTableWishlist);

        // Crea la tabla "elementos_wishlist"
        String createTableElementosWishlist = "CREATE TABLE IF NOT EXISTS `elementos_wishlist` ("
                + "`id_elementos_wishlist` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`wishlist_id_wishlist` INTEGER NOT NULL, "
                + "`movie_id_movie` INTEGER NOT NULL, "
                + "`cantidad` INTEGER, "
                + "FOREIGN KEY (`wishlist_id_wishlist`) REFERENCES `wishlist` (`id_wishlist`), "
                + "FOREIGN KEY (`movie_id_movie`) REFERENCES `movie` (`id_movie`));";
        db.execSQL(createTableElementosWishlist);

        String createTableCalificaciones = "CREATE TABLE IF NOT EXISTS `calificaciones` ("
                + "`id_calificacion` INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "`movie_id` INTEGER NOT NULL, "
                + "`usuario_id` INTEGER NOT NULL, "
                + "`puntuacion` INTEGER NOT NULL, "
                + "FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id_movie`));";
        db.execSQL(createTableCalificaciones);

        // Inserta directores
        db.execSQL("INSERT INTO director (nombre, apellido) VALUES ('Christopher', 'Nolan');");
        db.execSQL("INSERT INTO director (nombre, apellido) VALUES ('David', 'Fincher');");
        db.execSQL("INSERT INTO director (nombre, apellido) VALUES ('Damien', 'Chazelle');");
        db.execSQL("INSERT INTO director (nombre, apellido) VALUES ('Darren', 'Aronofsky');");
        // Inserta idiomas
        db.execSQL("INSERT INTO idioma (nombre) VALUES ('Español');");
        db.execSQL("INSERT INTO idioma (nombre) VALUES ('Inglés');");
        db.execSQL("INSERT INTO idioma (nombre) VALUES ('Francés');");
        db.execSQL("INSERT INTO idioma (nombre) VALUES ('Inglés');");
        db.execSQL("INSERT INTO idioma (nombre) VALUES ('Inglés');");

        // Inserta formatos
        db.execSQL("INSERT INTO formato (tipo) VALUES ('IMAX');");
        db.execSQL("INSERT INTO formato (tipo) VALUES ('3D');");
        db.execSQL("INSERT INTO formato (tipo) VALUES ('4K');");
        db.execSQL("INSERT INTO formato (tipo) VALUES ('4K');");
        db.execSQL("INSERT INTO formato (tipo) VALUES ('4K');");

        // Inserta productoraes
        db.execSQL("INSERT INTO productora (nombre) VALUES ('20th Century Fox');");
        db.execSQL("INSERT INTO productora (nombre) VALUES ('Arnold Kopelson Productions');");
        db.execSQL("INSERT INTO productora (nombre) VALUES ('Blumhouse');");
        db.execSQL("INSERT INTO productora (nombre) VALUES ('Universal');");
        db.execSQL("INSERT INTO productora (nombre) VALUES ('A24');");

        // Inserta categorías
        db.execSQL("INSERT INTO categoria (tipo) VALUES ('Ciencia Ficción');");
        db.execSQL("INSERT INTO categoria (tipo) VALUES ('Crimen/Thriller');");
        db.execSQL("INSERT INTO categoria (tipo) VALUES ('Drama');");

        //Insertar usuarios
        db.execSQL("INSERT INTO cliente (nombre, apellido, password, tipo_usuario, email, dni, fecha_nac, telefono, fecha_creacion, fecha_modificacion) VALUES ('Juan', 'Pérez', 'passJuan123', 1, 'juan@mail.com', '30123456', '1980-12-01', '5551234', CURRENT_DATE, CURRENT_DATE);");
        db.execSQL("INSERT INTO cliente (nombre, apellido, password, tipo_usuario, email, dni, fecha_nac, telefono, fecha_creacion, fecha_modificacion) VALUES ('Ana', 'García', 'passAna456', 1, 'ana@mail.com', '40123457', '1985-05-15', '5555678', CURRENT_DATE, CURRENT_DATE);");
        db.execSQL("INSERT INTO cliente (nombre, apellido, password, tipo_usuario, email, dni, fecha_nac, telefono, fecha_creacion, fecha_modificacion) VALUES ('Luis', 'Rodriguez', 'passLuis789', 1, 'luis@mail.com', '50123458', '1990-09-21', '5559101', CURRENT_DATE, CURRENT_DATE);");

        // Calificaciones
        db.execSQL("INSERT INTO calificaciones (movie_id, usuario_id, puntuacion) VALUES (1, 1, 5);");
        db.execSQL("INSERT INTO calificaciones (movie_id, usuario_id, puntuacion) VALUES (1, 2, 4);");
        db.execSQL("INSERT INTO calificaciones (movie_id, usuario_id, puntuacion) VALUES (1, 3, 5);");
        db.execSQL("INSERT INTO calificaciones (movie_id, usuario_id, puntuacion) VALUES (2, 1, 4);");
        db.execSQL("INSERT INTO calificaciones (movie_id, usuario_id, puntuacion) VALUES (2, 3, 4);");
        db.execSQL("INSERT INTO calificaciones (movie_id, usuario_id, puntuacion) VALUES (3, 2, 5);");
        db.execSQL("INSERT INTO calificaciones (movie_id, usuario_id, puntuacion) VALUES (3, 3, 4);");

        // Inserta movies
        db.execSQL("INSERT INTO movie (titulo, subtitulo, descripcion, comentarios, director_id_director, idioma_id_idioma, formato_id_formato, productora_id_productora, categoria_id_categoria, calificacion_promedio, numero_calificaciones) VALUES ('Interstellar', 'Subtítulo del movie', 'Al ver que la vida en la Tierra está llegando a su fin, un grupo de exploradores dirigidos por el piloto Cooper (McConaughey) y la científica Amelia (Hathaway) emprende una misión que puede ser la más importante de la historia de la humanidad: viajar más allá de nuestra galaxia para descubrir algún planeta en otra que pueda garantizar el futuro de la raza humana', 'Comentarios sobre el movie de este director', 1, 2, 3, 1, 1, 4.5, 3);");
        db.execSQL("INSERT INTO movie (titulo, subtitulo, descripcion, comentarios, director_id_director, idioma_id_idioma, formato_id_formato, productora_id_productora, categoria_id_categoria, calificacion_promedio, numero_calificaciones) VALUES ('Seven', 'Subtítulo del movie', 'Dos detectives, Somerset y Mills, persiguen a un astuto asesino en serie que comete crímenes atroces basados en los siete pecados capitales. La narrativa oscura y tensa revela giros impactantes hasta su impactante conclusión.', 'Comentarios sobre el movie de este director', 2, 1, 3, 2, 2, 4.0, 2);");
        db.execSQL("INSERT INTO movie (titulo, subtitulo, descripcion, comentarios, director_id_director, idioma_id_idioma, formato_id_formato, productora_id_productora, categoria_id_categoria, calificacion_promedio, numero_calificaciones) VALUES ('Whiplash', 'Subtítulo del movie', 'Un ambicioso baterista, Andrew, enfrenta la brutalidad de su exigente instructor de música, Fletcher, en la búsqueda obsesiva de la perfección en \"Whiplash\".', 'Comentarios sobre el movie de este director', 3, 2, 3, 3, 3, 4.7, 2);");
        db.execSQL("INSERT INTO movie (titulo, subtitulo, descripcion, comentarios, director_id_director, idioma_id_idioma, formato_id_formato, productora_id_productora, categoria_id_categoria, calificacion_promedio, numero_calificaciones) VALUES ('Oppenheimer', 'Subtítulo del movie', 'Durante la Segunda Guerra Mundial, el teniente general Leslie Groves designa al físico J. Robert Oppenheimer para un grupo de trabajo que está desarrollando el Proyecto Manhattan, cuyo objetivo consiste en fabricar la primera bomba atómica.', 'Comentarios sobre el movie de este director', 1, 3, 3, 2, 3, 4.7, 3);");
        db.execSQL("INSERT INTO movie (titulo, subtitulo, descripcion, comentarios, director_id_director, idioma_id_idioma, formato_id_formato, productora_id_productora, categoria_id_categoria, calificacion_promedio, numero_calificaciones) VALUES ('The Whale', 'Subtítulo del movie', 'Un profesor de inglés, un tipo solitario que sufre obesidad mórbida, intenta restablecer el contacto con su hija en busca de perdón.', 'Comentarios sobre el movie de este director', 4, 4, 4, 3, 3, 4.7, 4);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int versionAnterior, int versionNueva) {
        // Método para gestionar actualizaciones de la base de datos
    }

    // Método para actualizar la información del usuario
    public boolean updateUser(UserClass updatedUser) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("nombre", updatedUser.getNombre());
        contentValues.put("apellido", updatedUser.getApellido());
        contentValues.put("email", updatedUser.getEmail());
        contentValues.put("dni", updatedUser.getDni());
        contentValues.put("fecha_nac", updatedUser.getFecha_nac());

        String[] whereArgs = {String.valueOf(updatedUser.getIdUser())};
        int result = db.update("cliente", contentValues, "id_usuario=?", whereArgs);

        return result > 0;
    }



    // Registro
    public void createUser(Context context, String nombre, String apellido, String password, String email) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("nombre", nombre);
        values.put("apellido", apellido);
        values.put("password", password);
        values.put("email", email);
        values.put("tipo_usuario", 2);
        values.put("fecha_creacion", getCurrentDate());

        long userId = db.insert("cliente", null, values);

        if (userId == -1) {
            Toast.makeText(context, "Error en el registro", Toast.LENGTH_SHORT).show();
        } else {
            // Creamos wishlist para el usuario registrado
            ContentValues wishlistValues = new ContentValues();
            wishlistValues.put("cliente_id_usuario", userId);
            wishlistValues.put("fecha_creacion", getCurrentDate());
            long wishlistId = db.insert("wishlist", null, wishlistValues);
            if (wishlistId == -1) {
                Toast.makeText(context, "Error creando wishlist", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Registro exitoso!", Toast.LENGTH_SHORT).show();
            }
        }

        db.close();
    }

    // Eliminar usuario

    public void deleteUser(long id){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = { String.valueOf(id) };
        db.execSQL("DELETE FROM cliente WHERE id_usuario=?", args);
    }

    // Verifica si el email existe
    public boolean isEmailRegistered(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM cliente WHERE email = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email});
        if (cursor.getCount() <= 0) {
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

    // Login
    public boolean validateUserCredentials(Context context, String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM cliente WHERE email = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email, password});
        if (cursor.getCount() <= 0) {
            cursor.close();
            return false;
        }
        cursor.moveToFirst();

        int columnIndex = cursor.getColumnIndex("id_usuario");
        if(columnIndex != -1) {
            long userId = cursor.getLong(columnIndex);
            // Guardar el ID del usuario en Preferencias Compartidas para dsp poder obtenerlo
            SharedPreferences sharedPreferences = context.getSharedPreferences("UserPreferences", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putLong("userId", userId);
            editor.apply();
        } else {
            Toast.makeText(context, "Internal error.", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
        return true;
    }

    //Obtener usuario logeado
    public long getLoggedUserId(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("UserPreferences", Context.MODE_PRIVATE);
        long userId = sharedPreferences.getLong("userId", -1);
        Log.d("Wishlist", "Retrieved User ID: " + userId);
        return userId;  // Returns -1 if the user ID is not found
    }

    // Intenta autenticar al usuario localmente (en SQLite)
    public long authenticateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT id_usuario FROM cliente WHERE email = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email, password});

        long userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getLong(0);
        }

        cursor.close();
        return userId;
    }

    // Obtener la wishlist
    public long getWishlist(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT id_wishlist FROM wishlist WHERE cliente_id_usuario = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
        long wishlistId = -1;
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex("id_wishlist");
            if(columnIndex != -1) {
                wishlistId = cursor.getLong(columnIndex);
            }
        }
        cursor.close();
        return wishlistId;
    }

    // Agregar movie a la wishlist
    public boolean addToWishlist(long wishlistId, long movieId) {
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("wishlist_id_wishlist", wishlistId);
        contentValues.put("movie_id_movie", movieId);
        long result = db.insert("elementos_wishlist", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean delFromWishlist(long wishlistId, long movieId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = { String.valueOf(wishlistId), String.valueOf(movieId) };
        db.execSQL("DELETE FROM elementos_wishlist WHERE wishlist_id_wishlist=? AND movie_id_movie=?", args);
        //
        return true;
    }

    // Metodo para saber si el movie ya esta en la lista
    public List<Integer> getMovieIdsInWishlist(long clienteId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Integer> moviesInWishlist = new ArrayList<>();
        // Consulta SQL para obtener los movies en la wishlist del cliente
        String consulta = "SELECT movie_id_movie FROM elementos_wishlist WHERE wishlist_id_wishlist IN (SELECT id_wishlist FROM wishlist WHERE cliente_id_usuario = ?)";
        Cursor cursor = db.rawQuery(consulta, new String[]{String.valueOf(clienteId)});

        int columnIndex = cursor.getColumnIndex("movie_id_movie");

        while (cursor.moveToNext()) {
            if (columnIndex != -1) {
                int movieId = cursor.getInt(columnIndex);
                moviesInWishlist.add(movieId);
            }
        }

        cursor.close();
        return moviesInWishlist;
    }

    // Método para traer todos los movies de la wishlist del usuario logueado.
    public List<MovieClass> getMoviesInWishlist(long usuarioId){

        List<MovieClass> movies = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT movie_id_movie FROM elementos_wishlist WHERE wishlist_id_wishlist IN (SELECT id_wishlist FROM wishlist WHERE cliente_id_usuario = ?)";

        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(usuarioId)});

        int columnIndex = cursor.getColumnIndex("movie_id_movie");

        while (cursor.moveToNext()) {
            if (columnIndex != -1) {
                int movieId = cursor.getInt(columnIndex);
                MovieClass movie = getMovieById(movieId);
                movies.add(movie);
            }
        }
        cursor.close();
        return movies;
    }

    // Metodo auxiliar para obtener la fecha actual.
    private String getCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    // Obtener todos los movies de la DB.
    public List<MovieClass> getAllMovies() {

        List<MovieClass> movies = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM movie";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range")
                int id = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_ID));
                @SuppressLint("Range")
                String title = cursor.getString(cursor.getColumnIndex(MovieClass.COLUMN_TITULO));
                @SuppressLint("Range")
                String subtitle = cursor.getString(cursor.getColumnIndex(MovieClass.COLUMN_SUBTITULO));
                @SuppressLint("Range")
                String description = cursor.getString(cursor.getColumnIndex(MovieClass.COLUMN_DESCRIPCION));
                @SuppressLint("Range")
                String comments = cursor.getString(cursor.getColumnIndex(MovieClass.COLUMN_COMENTARIOS));
                @SuppressLint("Range")
                int directorId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_DIRECTOR_ID));
                @SuppressLint("Range")
                int languageId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_IDIOMA_ID));
                @SuppressLint("Range")
                int formatId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_FORMATO_ID));
                @SuppressLint("Range")
                int productoraId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_PRODUCTORA_ID));
                @SuppressLint("Range")
                int categoryId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_CATEGORIA_ID));
                @SuppressLint("Range")
                float score = cursor.getFloat(cursor.getColumnIndex(MovieClass.COLUMN_CALIFICACION_PROMEDIO));
                @SuppressLint("Range")
                int numberScores = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_NUMERO_CALIFICACIONES));

                MovieClass movie = new MovieClass(id, title, subtitle, description, comments, directorId, languageId, formatId, productoraId, categoryId, score, numberScores);

                movies.add(movie);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return movies;
    }

    public MovieClass getMovieById (int idmovie) {
        //metodo para retornar objeto movie por id
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM movie WHERE id_movie = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(idmovie)});

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            @SuppressLint("Range")
            int id = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_ID));
            @SuppressLint("Range")
            String title = cursor.getString(cursor.getColumnIndex(MovieClass.COLUMN_TITULO));
            @SuppressLint("Range")
            String subtitle = cursor.getString(cursor.getColumnIndex(MovieClass.COLUMN_SUBTITULO));
            @SuppressLint("Range")
            String description = cursor.getString(cursor.getColumnIndex(MovieClass.COLUMN_DESCRIPCION));
            @SuppressLint("Range")
            String comments = cursor.getString(cursor.getColumnIndex(MovieClass.COLUMN_COMENTARIOS));
            @SuppressLint("Range")
            int directorId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_DIRECTOR_ID));
            @SuppressLint("Range")
            int languageId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_IDIOMA_ID));
            @SuppressLint("Range")
            int formatId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_FORMATO_ID));
            @SuppressLint("Range")
            int productoraId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_PRODUCTORA_ID));
            @SuppressLint("Range")
            int categoryId = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_CATEGORIA_ID));
            @SuppressLint("Range")
            float score = cursor.getFloat(cursor.getColumnIndex(MovieClass.COLUMN_CALIFICACION_PROMEDIO));
            @SuppressLint("Range")
            int numberScores = cursor.getInt(cursor.getColumnIndex(MovieClass.COLUMN_NUMERO_CALIFICACIONES));

            MovieClass movie = new MovieClass(id, title, subtitle, description, comments, directorId, languageId, formatId, productoraId, categoryId, score, numberScores);
            cursor.close();
            return movie;
        } else {
            cursor.close();
            return null;
        }
    }

    //Método para retornar objeto User
    public UserClass getUserById (long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM cliente WHERE id_usuario = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(userId)});

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            @SuppressLint("Range")
            int id_usuario = cursor.getInt(cursor.getColumnIndex(UserClass.COLUMN_ID));
            @SuppressLint("Range")
            String nombre = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_NOMBRE));
            @SuppressLint("Range")
            String apellido = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_APELLIDO));
            @SuppressLint("Range")
            String password = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_PASSWORD));
            @SuppressLint("Range")
            String tipo_usuario = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_TIPO_USUARIO));
            @SuppressLint("Range")
            String email = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_EMAIL));
            @SuppressLint("Range")
            String dni = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_DNI));
            @SuppressLint("Range")
            String fecha_nac = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_FECHA_NAC));
            @SuppressLint("Range")
            String telefono = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_TELEFONO));
            @SuppressLint("Range")
            String fecha_creacion = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_FECHA_CREACION));
            @SuppressLint("Range")
            String fecha_modificacion = cursor.getString(cursor.getColumnIndex(UserClass.COLUMN_FECHA_MODIFICACION));

            UserClass user = new UserClass ( id_usuario, nombre, apellido, password, tipo_usuario, email, dni, fecha_nac, telefono, fecha_creacion, fecha_modificacion);
            cursor.close();
            return user;
        } else {
            cursor.close();
            return null;
        }
    }

    //Actualizar calificación del movie.
    public void rateMovie(int movieId, float userRating) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT calificacion_promedio, numero_calificaciones FROM movie WHERE id_movie = ?", new String[]{String.valueOf(movieId)});

        if (cursor.moveToFirst()) {
            int ratingIndex = cursor.getColumnIndex("calificacion_promedio");
            int numberRatingsIndex = cursor.getColumnIndex("numero_calificaciones");

            if (ratingIndex != -1 && numberRatingsIndex != -1) {
                double currentRating = cursor.getDouble(ratingIndex);
                int numberRatings = cursor.getInt(numberRatingsIndex);

                // Nueva calificación promedio
                double newRating = ((currentRating * numberRatings) + userRating) / (numberRatings + 1);
                int newNumberRatings = numberRatings + 1;

                ContentValues values = new ContentValues();
                values.put("calificacion_promedio", newRating);
                values.put("numero_calificaciones", newNumberRatings);

                db.update("movie", values, "id_movie = ?", new String[]{String.valueOf(movieId)});
            } else {
                Log.e("rateMovie", "error saving score in database");
            }
        }

        cursor.close();
    }

    // Obtener todas las productoraes de la db
    public List<ProductoraClass> getAllPublishers() {
        List<ProductoraClass> publishers = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM productora";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range")
                int id = cursor.getInt(cursor.getColumnIndex(ProductoraClass.COLUMN_ID));
                @SuppressLint("Range")
                String name = cursor.getString(cursor.getColumnIndex(ProductoraClass.COLUMN_NAME));

                ProductoraClass publisher = new ProductoraClass(id, name);

                publishers.add(publisher);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return publishers;
    }

    public ProductoraClass getPublisherById (int idProductora) {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM productora WHERE id_productora = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(idProductora)});

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            @SuppressLint("Range")
            int id_productora = cursor.getInt(cursor.getColumnIndex(ProductoraClass.COLUMN_ID));
            @SuppressLint("Range")
            String nombre = cursor.getString(cursor.getColumnIndex(ProductoraClass.COLUMN_NAME));

            ProductoraClass publisher = new ProductoraClass(id_productora, nombre);
            cursor.close();
            return publisher;
        } else {
            cursor.close();
            return null;
        }
    }

    // Obtener todos los formatos

    public List<FormatClass> getAllFormats() {
        List<FormatClass> formats = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM formato";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range")
                int id = cursor.getInt(cursor.getColumnIndex(FormatClass.COLUMN_ID));
                @SuppressLint("Range")
                String tipo = cursor.getString(cursor.getColumnIndex(FormatClass.COLUMN_TYPE));

                FormatClass format = new FormatClass(id, tipo);

                formats.add(format);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return formats;
    }

    public FormatClass getFormatById (int idFormat) {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM formato WHERE id_formato = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(idFormat)});

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            @SuppressLint("Range")
            int id_formato = cursor.getInt(cursor.getColumnIndex(FormatClass.COLUMN_ID));
            @SuppressLint("Range")
            String tipo = cursor.getString(cursor.getColumnIndex(FormatClass.COLUMN_TYPE));

            FormatClass format = new FormatClass(id_formato, tipo);
            cursor.close();
            return format;
        } else {
            cursor.close();
            return null;
        }
    }

    // Obtener todos los idiomas
    public List<LanguageClass> getAllLanguages() {
        List<LanguageClass> languages = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM idioma";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range")
                int id = cursor.getInt(cursor.getColumnIndex(LanguageClass.COLUMN_ID));
                @SuppressLint("Range")
                String nombre = cursor.getString(cursor.getColumnIndex(LanguageClass.COLUMN_NAME));

                LanguageClass language = new LanguageClass(id, nombre);

                languages.add(language);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return languages;
    }

    public LanguageClass getLanguageById (int idLanguage) {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM idioma WHERE id_idioma = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(idLanguage)});

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            @SuppressLint("Range")
            int id_idioma = cursor.getInt(cursor.getColumnIndex(LanguageClass.COLUMN_ID));
            @SuppressLint("Range")
            String nombre = cursor.getString(cursor.getColumnIndex(LanguageClass.COLUMN_NAME));

            LanguageClass language = new LanguageClass(id_idioma, nombre);
            cursor.close();
            return language;
        } else {
            cursor.close();
            return null;
        }
    }

    // Obtener todas las categorias
    public List<CategoryClass> getAllCategories() {
        List<CategoryClass> categories = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM categoria";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range")
                int id = cursor.getInt(cursor.getColumnIndex(CategoryClass.COLUMN_ID));
                @SuppressLint("Range")
                String tipo = cursor.getString(cursor.getColumnIndex(CategoryClass.COLUMN_TYPE));

                CategoryClass category = new CategoryClass(id, tipo);

                categories.add(category);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return categories;
    }

    public CategoryClass getCategoryById (int idCategory) {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM categoria WHERE id_categoria = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(idCategory)});

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            @SuppressLint("Range")
            int id_categoria = cursor.getInt(cursor.getColumnIndex(CategoryClass.COLUMN_ID));
            @SuppressLint("Range")
            String tipo = cursor.getString(cursor.getColumnIndex(CategoryClass.COLUMN_TYPE));

            CategoryClass category = new CategoryClass(id_categoria, tipo);
            cursor.close();
            return category;
        } else {
            cursor.close();
            return null;
        }
    }

    // Obtener todos los directores
    public List<DirectorClass> getAllDirectors() {
        List<DirectorClass> directors = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM director";
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range")
                int id = cursor.getInt(cursor.getColumnIndex(DirectorClass.COLUMN_ID));
                @SuppressLint("Range")
                String firstname = cursor.getString(cursor.getColumnIndex(DirectorClass.COLUMN_FIRST_NAME));
                @SuppressLint("Range")
                String lastname = cursor.getString(cursor.getColumnIndex(DirectorClass.COLUMN_LAST_NAME));

                DirectorClass director = new DirectorClass(id, firstname, lastname);

                directors.add(director);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return directors;
    }

    public DirectorClass getDirectorById (int idDirector) {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM director WHERE id_director = ?";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(idDirector)});

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            @SuppressLint("Range")
            int id = cursor.getInt(cursor.getColumnIndex(DirectorClass.COLUMN_ID));
            @SuppressLint("Range")
            String firstname = cursor.getString(cursor.getColumnIndex(DirectorClass.COLUMN_FIRST_NAME));
            @SuppressLint("Range")
            String lastname = cursor.getString(cursor.getColumnIndex(DirectorClass.COLUMN_LAST_NAME));

            DirectorClass director = new DirectorClass(id, firstname, lastname);
            cursor.close();
            return director;
        } else {
            cursor.close();
            return null;
        }
    }
}

