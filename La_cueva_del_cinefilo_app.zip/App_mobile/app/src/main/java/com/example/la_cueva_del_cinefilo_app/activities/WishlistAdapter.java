package com.example.la_cueva_del_cinefilo_app.activities;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.la_cueva_del_cinefilo_app.DataBaseSQLiteHelper;
import com.example.la_cueva_del_cinefilo_app.R;
import com.example.la_cueva_del_cinefilo_app.models.DirectorClass;
import com.example.la_cueva_del_cinefilo_app.models.MovieClass;

import java.util.List;

public class WishlistAdapter extends RecyclerView.Adapter<WishlistAdapter.ViewHolder> {
    private List<MovieClass> data;
    private Context context;

    private WishlistAdapter.OnItemClickListener enviarMovie;

    DataBaseSQLiteHelper dbHelper;

    public interface OnItemClickListener {
        void enviarMovie(MovieClass movie);
    }

    public WishlistAdapter(Context context, List<MovieClass> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.wishlist_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WishlistAdapter.ViewHolder holder, int position) {
        dbHelper = new DataBaseSQLiteHelper(this.context);

        final MovieClass movie = data.get(position);

        // Traer id del director.
        int directorId = movie.getDirectorId();

        // Obtener el director.
        DirectorClass director = dbHelper.getDirectorById(directorId);

        holder.textTitleW.setText(movie.getTitle());
        holder.textDescriptionW.setText(movie.getDescription());
        holder.ratingMovieW.setRating(movie.getScore());
        holder.textDirectorW.setText(director.getFullName());

        // Obtener el nombre de la película para construir el nombre del recurso de imagen
        String imageName = "ic_" + movie.getTitle().toLowerCase().replace(" ", "_");

        // Obtener la referencia al ImageView de la tapa del movie.
        ImageView movieCoverImageView = holder.itemView.findViewById(R.id.imageView4);

        // Cargar la imagen en el ImageView
        int resourceId = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        if (resourceId != 0) {
            movieCoverImageView.setImageResource(resourceId);
        }

        // Configurar el OnClickListener en la tapa del movie.
        movieCoverImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (enviarMovie != null) {
                    enviarMovie.enviarMovie(movie);
                }
            }
        });
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        enviarMovie = listener;
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textTitleW;
        TextView textDescriptionW;

        RatingBar ratingMovieW;

        TextView textDirectorW;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitleW = itemView.findViewById(R.id.textTitleW);
            textDescriptionW = itemView.findViewById(R.id.textDescriptionW);
            ratingMovieW = itemView.findViewById(R.id.ratingMovieW);
            textDirectorW = itemView.findViewById(R.id.textDirectorW);
        }
    }
}
