package com.example.la_cueva_del_cinefilo_app.activities;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.la_cueva_del_cinefilo_app.DataBaseSQLiteHelper;
import com.example.la_cueva_del_cinefilo_app.R;
import com.example.la_cueva_del_cinefilo_app.models.MovieClass;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;
public class MainActivity extends AppCompatActivity  implements MovieAdapter.OnItemClickListener, MovieAdapter.OnRatingChangeListener {
    DataBaseSQLiteHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Instanciar un objeto de la clase DataBaseSQLiteHelper.
        dbHelper = new DataBaseSQLiteHelper(this);

        // Guardar la lista en una variable.
        List<MovieClass> response = dbHelper.getAllMovies();

        // Configurar el RecyclerView y su adaptador
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        MovieAdapter adapter = new MovieAdapter(this, response);

        adapter.setOnItemClickListener(this); // Establecer el listener en MainActivity
        adapter.setOnRatingChangeListener(this);



        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Navegación.
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.bottom_inicio);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.bottom_inicio) {
                return true;
            } else if (item.getItemId() == R.id.bottom_deseos) {
                startActivity(new Intent(getApplicationContext(), WishlistActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                //finish();
                return true;
            } else if (item.getItemId() == R.id.bottom_cotacto ) {
                startActivity(new Intent(getApplicationContext(), ContactActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                //finish();
                return true;
            } else if (item.getItemId() == R.id.bottom_perfil) {
                startActivity(new Intent(getApplicationContext(), accountactivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                //finish();
                return true;
            }
            return false;
        });
    }

    @Override
    public void enviarMovie(MovieClass movie) {
        // Obtener el ID del movie.
        int movieId = movie.getId();

        // Crear un Intent para abrir la actividad MovieDetail.
        Intent intent = new Intent(this, MovieDetail.class);

        // Pasar el ID del movie como extra en el Intent
        intent.putExtra("movie_id", movieId);

        // Iniciar la actividad MovieDetail
        startActivity(intent);
    }

    @Override
    public void onRatingChange(int movieId, float newRating) {
        dbHelper.rateMovie(movieId, newRating);
    }
}