package com.example.la_cueva_del_cinefilo_app.activities;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.la_cueva_del_cinefilo_app.DataBaseSQLiteHelper;
import com.example.la_cueva_del_cinefilo_app.R;
import com.example.la_cueva_del_cinefilo_app.models.DirectorClass;
import com.example.la_cueva_del_cinefilo_app.models.MovieClass;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder> {
    private List<MovieClass> data;
    private Context context;

    private OnItemClickListener enviarMovie;

    private OnRatingChangeListener onRatingChangeListener;

    DataBaseSQLiteHelper dbHelper;

    public interface OnItemClickListener {
        void enviarMovie(MovieClass movie);
    }

    public interface OnRatingChangeListener {
        void onRatingChange(int movieId, float rating);
    }

    public MovieAdapter(Context context, List<MovieClass> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        dbHelper = new DataBaseSQLiteHelper(this.context);

        final MovieClass movie = data.get(position);

        int directorId = movie.getDirectorId();
        DirectorClass director = dbHelper.getDirectorById(directorId);

        holder.textTitle.setText(movie.getTitle());
        holder.textDescription.setText(movie.getDescription());
        holder.ratingMovie.setRating(movie.getScore());
        holder.textDirector.setText(director.getFullName());

        // Obtener la referencia al ImageView de la tapa del movie.
        ImageView movieCoverImageView = holder.itemView.findViewById(R.id.imageView4);

        // Obtener el nombre de la película para construir el nombre del recurso de imagen
        String imageName = "ic_" + movie.getTitle().toLowerCase().replace(" ", "_");

        // Cargar la imagen en el ImageView
        int resourceId = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        if (resourceId != 0) {
            movieCoverImageView.setImageResource(resourceId);
        }

        // Listener para RatingBar
        holder.ratingMovie.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (fromUser && onRatingChangeListener != null) {
                    onRatingChangeListener.onRatingChange(movie.getId(), rating);
                }
            }
        });

        // Configurar el OnClickListener en la tapa del movie.
        movieCoverImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (enviarMovie != null) {
                    enviarMovie.enviarMovie(movie);
                }
            }
        });
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        enviarMovie = listener;
    }

    public void setOnRatingChangeListener(OnRatingChangeListener listener) {
        this.onRatingChangeListener = listener;
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle;
        TextView textDescription;
        RatingBar ratingMovie;

        TextView textDirector;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.textTitle);
            textDescription = itemView.findViewById(R.id.textDescription);
            ratingMovie = itemView.findViewById(R.id.ratingMovie);
            textDirector = itemView.findViewById(R.id.textDirector);
        }
    }
}

