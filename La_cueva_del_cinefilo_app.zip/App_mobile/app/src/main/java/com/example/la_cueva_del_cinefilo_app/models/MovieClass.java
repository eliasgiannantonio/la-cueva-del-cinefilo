package com.example.la_cueva_del_cinefilo_app.models;

import com.example.la_cueva_del_cinefilo_app.interfaces.IMovie;

public class MovieClass implements IMovie {
    public static String COLUMN_ID = "id_movie";
    public static final String COLUMN_TITULO = "titulo";
    public static final String COLUMN_SUBTITULO = "subtitulo";
    public static final String COLUMN_DESCRIPCION = "descripcion";
    public static final String COLUMN_COMENTARIOS = "comentarios";
    public static final String COLUMN_DIRECTOR_ID = "director_id_director";
    public static final String COLUMN_IDIOMA_ID = "idioma_id_idioma";
    public static final String COLUMN_FORMATO_ID = "formato_id_formato";
    public static final String COLUMN_PRODUCTORA_ID = "productora_id_productora";
    public static final String COLUMN_CATEGORIA_ID = "categoria_id_categoria";
    public static final String COLUMN_CALIFICACION_PROMEDIO = "calificacion_promedio";
    public static final String COLUMN_NUMERO_CALIFICACIONES = "numero_calificaciones";



    private int id;
    private String title;
    private String subtitle;
    private String description;
    private String comments;
    private int directorId;
    private int languageId;
    private int formatId;
    private int productoraId;
    private int categoryId;

    private float score;
    private int numberScores;

    public MovieClass(int id, String title, String subtitle, String description, String comments, int directorId, int languageId, int formatId, int productoraId, int categoryId, float score, int numberScores) {
        this.id = id;
        this.title = title;
        this.subtitle = subtitle;
        this.description = description;
        this.comments = comments;
        this.directorId = directorId;
        this.languageId = languageId;
        this.formatId = formatId;
        this.productoraId = productoraId;
        this.categoryId = categoryId;
        this.score = score;
        this.numberScores = numberScores;
    }

    public MovieClass(int idUsuario, String nombre, String apellido, String password, String tipoUsuario, String email, String dni, String fechaNac, String telefono, String fechaCreacion, String fechaModificacion) {
    }

    public int getId() {
        return id;
    }


    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getDescription() {
        return description;
    }

    public String getComments() {
        return comments;
    }

    public int getDirectorId() {
        return directorId;
    }

    public int getLanguageId() {
        return languageId;
    }

    public int getFormatId() {
        return formatId;
    }

    public int getProductoraId() {
        return productoraId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public float getScore() {
        return score;
    }

    public int getNumberScores() {
        return numberScores;
    }

}
