package com.example.la_cueva_del_cinefilo_app.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.la_cueva_del_cinefilo_app.DataBaseSQLiteHelper;
import com.example.la_cueva_del_cinefilo_app.R;
import com.example.la_cueva_del_cinefilo_app.models.UserClass;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class accountactivity extends AppCompatActivity {

    private ImageView ivRegresar;
    private Button btnCerrarSesion, button, buttonDelete;
    private TextView txtAcouNom, txtAcouApe, txtAcouEmail, txtAcouTelefono, txtAcouTitulo;

    private UserClass user;
    private DataBaseSQLiteHelper dbHelper;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accountactivity);

        dbHelper = new DataBaseSQLiteHelper(this);
        mAuth = FirebaseAuth.getInstance();

        ivRegresar = findViewById(R.id.ivRegresar);
        txtAcouNom = findViewById(R.id.txtAcouNom);
        txtAcouApe = findViewById(R.id.txtAcouApe);
        txtAcouEmail = findViewById(R.id.txtAcouEmail);
        txtAcouTelefono = findViewById(R.id.txtAcouTelefono);
        txtAcouTitulo = findViewById(R.id.txtAcouTitulo);
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);

        ivRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(accountactivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnCerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();
                Intent intent = new Intent(accountactivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(accountactivity.this, EditUserActivity.class);
                startActivity(intent);
            }
        });

        buttonDelete = findViewById(R.id.buttonDelete);
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseUser currentUser = mAuth.getCurrentUser();
                if (currentUser != null) {
                    currentUser.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull com.google.android.gms.tasks.Task<Void> task) {
                            if (task.isSuccessful()) {
                                dbHelper.deleteUser(user.getIdUser());
                                Toast.makeText(accountactivity.this, "Usuario eliminado exitosamente", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(accountactivity.this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(accountactivity.this, "Error al eliminar el usuario", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });

        updateUI(mAuth.getCurrentUser());
    }

    private void updateUI(FirebaseUser user) {
        if (user != null) {
            // Name, email, etc.
            String name = user.getDisplayName();
            String email = user.getEmail();

            // Update your views with user information
            if (name != null) {
                txtAcouNom.setText(name);
                txtAcouTitulo.setText("Hola " + name);
            } else {
                txtAcouNom.setText("Nombre no proporcionado");
                txtAcouTitulo.setText("Hola Usuario");
            }

            txtAcouEmail.setText(email);
        }
    }
}
