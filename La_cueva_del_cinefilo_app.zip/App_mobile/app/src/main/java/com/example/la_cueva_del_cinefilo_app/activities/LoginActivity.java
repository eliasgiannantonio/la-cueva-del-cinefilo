package com.example.la_cueva_del_cinefilo_app.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.la_cueva_del_cinefilo_app.DataBaseSQLiteHelper;
import com.example.la_cueva_del_cinefilo_app.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private DataBaseSQLiteHelper dbHelper;
    private FirebaseAuth mAuth;

    private EditText emailEditText;
    private EditText passwordEditText;
    private TextView registerTextView;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DataBaseSQLiteHelper(this);
        mAuth = FirebaseAuth.getInstance();

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        registerTextView = findViewById(R.id.registerTextView);
        loginButton = findViewById(R.id.loginButton);

        registerTextView.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        loginButton.setOnClickListener(v -> {
            if (areLoginFieldsValid()) {
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                // Utilizar Firebase para iniciar sesión
                signInWithFirebase(email, password);
            }
        });
    }

    private boolean areLoginFieldsValid() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showToast("Por favor, completa todos los campos.");
            return false;
        }

        return true;
    }

    private void signInWithFirebase(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        showToast("Inicio de sesión exitoso en Firebase.");

                        // Save user ID to SharedPreferences
                        if (user != null) {
                            long userId = dbHelper.authenticateUser(email, password); // Replace this with the correct method to get user ID
                            saveUserIDToSharedPreferences(userId);

                            // Now, try to sign in locally
                            signInLocally(email, password, user);
                        }
                    } else {
                        showToast("Error en el inicio de sesión en Firebase. Verifica los datos e inténtalo de nuevo.");
                        updateUI(null);
                    }
                });
    }

    private void saveUserIDToSharedPreferences(long userId) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong("userId", userId);
        editor.apply();
    }


    private void signInLocally(String email, String password, FirebaseUser firebaseUser) {
        // Try to sign in locally (in SQLite)
        long userId = dbHelper.authenticateUser(email, password);
        Log.d("Local", "Local User ID: " + userId);

        if (userId != -1) {
            showToast("Inicio de sesión exitoso localmente.");

            // Check if Firebase user is also authenticated
            if (firebaseUser != null) {
                // Both Firebase and local authentication successful
                updateUI(firebaseUser);
            } else {
                showToast("Esperando autenticación en Firebase...");
            }
        } else {
            showToast("Error en el inicio de sesión local. Verifica los datos e inténtalo de nuevo.");
            updateUI(null);
        }
    }


    private void showToast(String message) {
        Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    private void updateUI(FirebaseUser user) {
        if (user != null) {
            // El usuario ha iniciado sesión con éxito, puedes redirigir a la actividad principal
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            // El inicio de sesión falló, puedes realizar acciones adicionales si es necesario
        }
    }
}
