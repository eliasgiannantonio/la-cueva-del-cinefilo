package com.example.la_cueva_del_cinefilo_app.interfaces;

public interface IMovie {
    int getId();
    String getTitle();
    String getSubtitle();
    String getDescription();
    String getComments();
    int getDirectorId();
    int getLanguageId();
    int getFormatId();
    int getProductoraId();
    int getCategoryId();
    float getScore();
    int getNumberScores();
}
