package com.example.la_cueva_del_cinefilo_app.interfaces;

public interface ILanguage {
    int getId();
    String getName();
}