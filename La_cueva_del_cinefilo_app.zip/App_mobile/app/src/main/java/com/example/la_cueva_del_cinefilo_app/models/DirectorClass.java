package com.example.la_cueva_del_cinefilo_app.models;

import com.example.la_cueva_del_cinefilo_app.interfaces.IDirector;

public class DirectorClass implements IDirector {
    public static final String COLUMN_ID = "id_director";
    public static final String COLUMN_FIRST_NAME = "nombre";
    public static final String COLUMN_LAST_NAME = "apellido";

    private int id;
    private String firstName;
    private String lastName;

    public DirectorClass(int id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }
}