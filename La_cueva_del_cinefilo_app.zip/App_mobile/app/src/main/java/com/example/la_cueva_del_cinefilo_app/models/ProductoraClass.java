package com.example.la_cueva_del_cinefilo_app.models;

import com.example.la_cueva_del_cinefilo_app.interfaces.IProductora;

public class ProductoraClass implements IProductora {
    public static final String COLUMN_ID = "id_productora";
    public static final String COLUMN_NAME = "nombre";

    private int id;
    private String name;

    public ProductoraClass(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}