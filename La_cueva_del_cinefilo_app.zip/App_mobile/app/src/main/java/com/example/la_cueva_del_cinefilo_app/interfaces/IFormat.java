package com.example.la_cueva_del_cinefilo_app.interfaces;

public interface IFormat {
    int getId();
    String getType();
}