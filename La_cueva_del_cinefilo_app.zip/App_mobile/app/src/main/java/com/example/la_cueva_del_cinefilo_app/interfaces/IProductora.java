package com.example.la_cueva_del_cinefilo_app.interfaces;

public interface IProductora {
    int getId();
    String getName();
}
