package com.example.la_cueva_del_cinefilo_app.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.la_cueva_del_cinefilo_app.DataBaseSQLiteHelper;
import com.example.la_cueva_del_cinefilo_app.R;
import com.example.la_cueva_del_cinefilo_app.models.DirectorClass;
import com.example.la_cueva_del_cinefilo_app.models.MovieClass;
import com.example.la_cueva_del_cinefilo_app.models.CategoryClass;
import com.example.la_cueva_del_cinefilo_app.models.ProductoraClass;
import com.example.la_cueva_del_cinefilo_app.models.FormatClass;
import com.example.la_cueva_del_cinefilo_app.models.LanguageClass;

import java.util.List;

public class MovieDetail extends AppCompatActivity {
    ImageView ivRegresar;
    ImageView movieImage;
    TextView textTitle;
    TextView movieSubtitle;
    TextView movieDirector;
    TextView moviePrice;
    TextView movieCategorie;
    TextView movieDescriptionTitle;
    TextView textDescription;
    TextView movieSpecificationTitle;
    TextView movieProductoraTitle;
    TextView movieProductora;
    TextView movieFormatTitle;
    TextView movieFormat;
    TextView movieLanguageTitle;
    TextView movieLanguage;

    Button btnMovieAddWish;

    DataBaseSQLiteHelper dbHelper;
    MovieClass movie;

    List<Integer> moviesIdsInWishlist;

    long loggedUserId;
    long wishlistId;

    RatingBar movieRatingBar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        dbHelper = new DataBaseSQLiteHelper(this);
        //estan todos los bind completos
        textTitle = findViewById(R.id.textTitle);
        movieSubtitle = findViewById(R.id.movieSubtitle);
        movieDirector = findViewById(R.id.movieDirector);
        movieCategorie = findViewById(R.id.movieCategorie);
        movieImage = findViewById(R.id.movieImage);
        movieDescriptionTitle = findViewById(R.id.movieDescriptionTitle);
        movieSpecificationTitle = findViewById(R.id.movieSpecificationTitle);
        movieProductoraTitle = findViewById(R.id.movieProductoraTitle);
        movieProductora = findViewById(R.id.movieProductora);
        movieFormatTitle = findViewById(R.id.movieFormatTitle);
        movieFormat = findViewById(R.id.movieFormat);
        movieLanguageTitle = findViewById(R.id.movieLanguageTitle);
        movieLanguage = findViewById(R.id.movieLanguage);
        textDescription = findViewById(R.id.textDescription);
        btnMovieAddWish = findViewById(R.id.movieAddWish);
        movieRatingBar = findViewById(R.id.movieScore);

        ivRegresar = findViewById(R.id.ivRegresar);
        ivRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MovieDetail.this, MainActivity.class);
                startActivity(i);
            }
        });
        // traer usuario
        loggedUserId = dbHelper.getLoggedUserId(this);
        // traer movies de wishlist de usuario
        moviesIdsInWishlist = dbHelper.getMovieIdsInWishlist(loggedUserId);
        // traer id de wishlist de usuario logeado
        wishlistId = dbHelper.getWishlist(loggedUserId);

        // Recuperar el ID del movie de la Intent
        int movieId = getIntent().getIntExtra("movie_id", -1);

        if (movieId != -1) {
            movie = dbHelper.getMovieById(movieId);

            if (moviesIdsInWishlist.contains(movieId)) {
                btnMovieAddWish.setText("Eliminar de la Lista");
            }

            // Traer id del director.
            int directorId = movie.getDirectorId();

            // Obtener el director.
            DirectorClass director = dbHelper.getDirectorById(directorId);

            // Traer id de la categoría.
            int categoriaId = movie.getCategoryId();

            // Obtener el categoría.
            CategoryClass categoria = dbHelper.getCategoryById(categoriaId);

            // Traer id de la productora.
            int productoraId = movie.getProductoraId();

            // Obtener el categoría.
            ProductoraClass productora = dbHelper.getPublisherById(productoraId);

            // Traer id del formato.
            int formatoId = movie.getFormatId();

            // Obtener el categoría.
            FormatClass formato = dbHelper.getFormatById(formatoId);

            // Traer id del idioma.
            int idiomaId = movie.getLanguageId();

            // Obtener el categoría.
            LanguageClass idioma = dbHelper.getLanguageById(idiomaId);

            // Actualizar las vistas con los detalles del movie
            textTitle.setText(movie.getTitle());
            movieSubtitle.setText(movie.getSubtitle());
            movieDirector.setText(director.getFullName());
            movieCategorie.setText(categoria.getType());
            textDescription.setText(movie.getDescription());
            movieProductora.setText(productora.getName());
            movieFormat.setText(formato.getType());
            movieLanguage.setText(idioma.getName());

            // Cargar imagen en el ImageView
            loadMovieImage(movie);

            // Agregar movie a wishlist.
            if (moviesIdsInWishlist.contains(movieId)) {
                btnMovieAddWish.setText("Eliminar de la Lista");
            } else {
                btnMovieAddWish.setText("Agregar a la Lista");
            }

            // Agregar el evento de clic al botón
            btnMovieAddWish.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (btnMovieAddWish.getText().toString().equals("Agregar a la Lista")) {
                        // Agregar movie a la wishlist
                        dbHelper.addToWishlist(wishlistId, movieId);
                        btnMovieAddWish.setText("Eliminar de la Lista");
                    } else {
                        // Eliminar movie de la wishlist
                        dbHelper.delFromWishlist(wishlistId, movieId);
                        btnMovieAddWish.setText("Agregar a la Lista");
                    }
                }
            });

            movieRatingBar.setRating(movie.getScore());

            movieRatingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                    if (fromUser) {
                        dbHelper.rateMovie(movie.getId(), rating);
                    }
                }
            });

        } else {
            // Manejar el caso en el que no se haya encontrado el ID del movie
            Toast.makeText(this, "Pelicula no encontrada", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para cargar la imagen de la película en el ImageView
    private void loadMovieImage(MovieClass movie) {
        String movieTitle = movie.getTitle().toLowerCase().replace(" ", "_");
        String imageName = "ic_" + movieTitle;
        int imageResourceId = getResources().getIdentifier(imageName, "drawable", getPackageName());
        movieImage.setImageResource(imageResourceId);
    }
}
